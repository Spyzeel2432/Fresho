import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { User } from './models/User.js';

if (!process.env.MONGODB_URI || !process.env.JWT_SECRET) throw new Error('Configure backend/.env before seeding.');
await mongoose.connect(process.env.MONGODB_URI);
const email = (process.env.ADMIN_EMAIL || 'admin@fresho.in').toLowerCase();
const password = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
await User.findOneAndUpdate(
  { email },
  { name: 'Fresho Admin', email, role: 'admin', verified: true, passwordHash: await bcrypt.hash(password, 12) },
  { upsert: true, new: true, setDefaultsOnInsert: true }
);
console.log(`Admin account is ready for ${email}`);
await mongoose.disconnect();
